<?php

// THIS FILE IS NOT AFFECTED BY UPGRADES AND IS SAFE TO EDIT

// This file allows you to add an optional section to the client for your own entries

$userIns = '<div class="center">--- CHANGE TO USER OPTIONS EXAMPLE / INSTRUCTIONS ---<br><small>(file not yet actually safe to edit)</small></div>';

?>