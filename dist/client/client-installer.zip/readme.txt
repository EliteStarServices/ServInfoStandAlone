
	* @Project:
	* ServInfo Client Installer
	* Author: Elite Star Services
	* Web: https://servinfo.elite-star-services.com/
	* 
	* @License:
	* GPL v3 | https://elite-star-services.com/license/

Upload the file 'client-installer.php' to your php web server and execute.
Folder '/servinfo' will be created and the client will be installed to that folder.
Once installed, you can run the ServInfo Client and bookmark the page.