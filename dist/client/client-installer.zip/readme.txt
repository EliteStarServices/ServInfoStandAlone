
	* @Project:
	* ServInfo Client Installer
	* Author: DigTek (Elite Star Services)
	* Web: https://elite-star-services.com/servinfo
	* 
	* @License:
	* GPL v3 | https://elite-star-services.com/license/

ServInfo Project still in beta...

Upload the file 'client-installer.php' to your php web server and execute.
Folder '/servinfo' will be created and the client will be installed to that folder.
Once installed, you can run the ServInfo Client and bookmark the page.