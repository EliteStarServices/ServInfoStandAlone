<?php

// THIS FILE IS NOT AFFECTED BY UPGRADES AND IS SAFE TO EDIT

// This file allows you to add an optional section to the client for your own entries

$userIns = '<div class="center">--- USER OPTIONS EXAMPLE / INSTRUCTIONS ---<br><small>(Edit the file userInc.php to change this section, rename or delete to remove this section)</small></div>';

?>