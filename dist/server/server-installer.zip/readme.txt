
     * @Project:
     * ServInfo Server Installer
	* Author: Elite Star Services
	* Web: https://servinfo.elite-star-services.com/
     * 
     * @License:
	* GPL v3 | https://elite-star-services.com/license/

Upload the file 'server-installer.php' to your php web server and execute.
The ServInfo Server will be installed to that folder.

Once installed, you can run the ServInfo and bookmark the page.
* The Beta Server is NOT Secured and was designed as a LAN only tool.
! You must take measures of your own if placed in a public facing folder !