
     * @Project:
     * ServInfo Server Installer
	* Author: DigTek (Elite Star Services)
	* Web: https://elite-star-services.com/servinfo
     * 
     * @License:
	* GPL v3 | https://elite-star-services.com/license/

ServInfo Project still in beta...

Upload the file 'server-installer.php' to your php web server and execute.
The ServInfo Server will be installed to that folder.

Once installed, you can run the ServInfo and bookmark the page.
* The Beta Server is NOT Secured and was designed as a LAN only tool.
! You must take measures of your own if placed in a public facing folder !