<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">
	<i class="glyphicon glyphicon-briefcase"> </i>
	<?php echo "Custom Menu"; ?>
	<span class="caret"></span></a>
	<ul class="dropdown-menu">
	<li><a href="./info.php"><i class="fa fa-file-text-o fa-fw"></i> <?php echo 'ServInfo Server Info'; ?></a></li>
	<li><a href="https://elite-star-services.com"><i class="fa fa-user-o fa-fw"></i> <?php echo 'Contact Us'; ?></a></li>
	</ul>
</li>