<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">
	<i class="glyphicon glyphicon-briefcase"> </i>
	<?php echo "Custom Menu"; ?>
	<span class="caret"></span></a>
	<ul class="dropdown-menu">
		<li><a href="./sho_srv.php"><i class="fa fa-star fa-fw"> </i>Example Item</a></li>
	</ul>
</li>