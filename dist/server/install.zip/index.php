<?php
echo '<META HTTP-EQUIV="Refresh" Content="0; URL=sho_srv.php">';
?>